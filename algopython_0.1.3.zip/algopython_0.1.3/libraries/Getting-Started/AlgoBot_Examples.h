//This file allows the Algobrix Brain Block Examples to appear in the File > Examples menu and fixes the Invalid library warning in Arduino IDE 1.6.6+
