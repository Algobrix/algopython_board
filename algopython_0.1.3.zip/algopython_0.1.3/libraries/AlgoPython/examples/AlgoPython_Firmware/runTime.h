/* Define to prevent recursive inclusion *********************************** */
#ifndef __RUNTIME_H
#define __RUNTIME_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include "pinout.h"
#include "debug.h"

/* Exported constants ****************************************************** */
#define debugRUN                                    printDEBUG                      
/* #define debugRUN */                                                          

#define DURATION_MULTIPLIER 100L
#define MIN_TIME_VALUE 10L
#define MAX_TIME_VALUE 180L
#define SPEED_INTERVAL 100
#define PULSES_PER_ROTATION 687

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

enum MotorFSMState {
    MOTOR_IDLE,
    MOTOR_RUNNING,
    MOTOR_DONE
};

enum SoundState {
  SOUND_IDLE,
  SOUND_RUNNING,
  SOUND_DONE
};

enum LightState {
  LIGHT_IDLE,
  LIGHT_RUNNING,
  LIGHT_DONE
};

enum ResistanceState {
  RESISTANCE_IDLE,
  RESISTANCE_RUNNING,
  RESISTANCE_DONE
};

enum SensorFSMState {
  SENSOR_IDLE,
  SENSOR_RUNNING,
  SENSOR_INIT,
};

enum PlayBtnState {
  PLAY_ACTIVE,
  PLAY_INACTIVE
};

struct MotorCommand {
    uint32_t timer;
    uint32_t duration;
    uint8_t isActive;
    uint8_t reason;
    uint8_t state;
    uint8_t type;
};

struct LightCommand {
  uint32_t timer;
  uint32_t duration;
  uint8_t isActive;
  uint8_t state;
  uint8_t type;
};

struct SoundCommand {
  uint32_t timer;
  uint8_t Volume;
  uint8_t isActive;
  uint8_t state;
};

struct SensorCommand {
  uint8_t isActive;
  uint8_t state;
  uint8_t min;
  uint8_t max;
  uint8_t value;
  uint8_t masterUpdateFlag;
};

struct ResistanceStop {
  uint8_t isActive;
  uint8_t state;
  uint32_t timer;
  uint32_t diffTimer;
  uint8_t motor_port;
  float treshold;
  float startSpeed;
  float currentSpeed;
  float speedDiff;
  uint32_t prevEnc;
  uint32_t currEnc;
};

/* Exported variables ****************************************************** */
extern boolean changeSpeed; 
extern MotorCommand motorCmd[3];
/* Exported functions ****************************************************** */
void processThreads();
void processScriptRow(byte scriptRowId);
void getNextThread();
void getNextScriptRow(byte scriptRowId);
boolean processStartThread(byte scriptRowId);
boolean processStartLoop(byte scriptRowId);
boolean processEndLoop(byte scriptRowId);

/*AlgoPython Functions ------------------------------------------------------*/
void algopython_fsm_update();
void resistance_fsm_init();
void cmd_process_rotate(uint8_t motor_port, float rotations, uint8_t motor_power, int8_t motor_dir);

uint8_t cmd_process_light(uint8_t led_port, uint8_t led_type,float led_duration, uint8_t led_power, uint8_t led_r, uint8_t led_g, uint8_t led_b);
uint8_t cmd_process_light12(uint8_t led_type,float led_duration, uint8_t led_power, uint8_t led_r, uint8_t led_g, uint8_t led_b) ;
uint8_t cmd_process_move(uint8_t motor_port,uint8_t motor_type,float motor_duration ,uint8_t motor_power,uint8_t motor_dir); 
uint8_t cmd_process_playSound(uint8_t sound_id, uint8_t volume);
uint8_t cmd_process_move_stop(uint8_t motor_port);
uint8_t cmd_process_light_stop(uint8_t light_port);
uint8_t cmd_process_sound_stop();
uint8_t cmd_process_wait_sensor(uint8_t sensor_port, uint8_t min, uint8_t max);
uint8_t cmd_process_resistanceToStop(uint8_t motor_port, float treshold_val);

void fillStatusPayload(uint8_t* buf);
void startScriptRow(byte scriptRowId);
void finishedScriptRow(byte scriptRowId);
void ALGOPYTHON_motorAndDirectionHelper(byte directionDataByte, byte *motorAndDirection);
void motorAndDirectionHelper(byte directionDataByte, byte *motorAndDirection);
byte motorPowerHelper(byte powerDataByte);
//byte motorBalanceSpeed(int stepPow, int maxPower);


#endif 
/* ***************************** END OF FILE ******************************* */
